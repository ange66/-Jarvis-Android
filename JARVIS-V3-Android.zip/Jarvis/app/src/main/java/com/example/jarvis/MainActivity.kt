package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    // Modèle utilisé (modifiable)
    private val model = "claude-sonnet-5-5"

    private val system = "Tu es Jarvis, un assistant personnel vocal, poli et efficace, " +
        "qui répond en français. Réponses courtes (1 à 3 phrases), sans markdown ni listes, " +
        "adaptées à une lecture à voix haute. Appelle l'utilisateur « chef » de temps en temps."

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.FRENCH
        }
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (permissions.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) requestPermissions(permissions.toTypedArray(), 1)
    }

    override fun onDestroy() {
        tts?.shutdown()
        recognizer?.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    inner class Bridge {

        @JavascriptInterface fun hasKey(): Boolean = !prefs.getString("key", "").isNullOrBlank()
        @JavascriptInterface fun isWakeWordActive(): Boolean = prefs.getBoolean("wake_active", false)

        @JavascriptInterface fun setKey(k: String) { prefs.edit().putString("key", k.trim()).apply() }

        @JavascriptInterface fun startWakeWord() = runOnUiThread {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
                js("onWakeStatus(false, 'Autorise le microphone puis réessaie.')")
                return@runOnUiThread
            }
            try {
                val intent = Intent(this@MainActivity, WakeWordService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
                js("onWakeStatus(true, 'Mode Hey Jarvis activé')")
            } catch (e: Exception) {
                js("onWakeStatus(false, 'Impossible de démarrer l’écoute. Ouvre Jarvis puis réessaie.')")
            }
        }

        @JavascriptInterface fun stopWakeWord() = runOnUiThread {
            stopService(Intent(this@MainActivity, WakeWordService::class.java))
            js("onWakeStatus(false, 'Mode mains libres désactivé')")
        }

        @JavascriptInterface fun speak(text: String) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }

        @JavascriptInterface fun stopSpeaking() { tts?.stop() }

        @JavascriptInterface fun listen() = runOnUiThread {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                js("onSpeechError('Autorise le micro puis réessaie.')")
                return@runOnUiThread
            }
            if (!SpeechRecognizer.isRecognitionAvailable(this@MainActivity)) {
                js("onSpeechError('Reconnaissance vocale indisponible.')")
                return@runOnUiThread
            }
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this@MainActivity).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(results: android.os.Bundle?) {
                        val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                        js("onSpeech(${JSONObject.quote(t)})")
                    }
                    override fun onError(error: Int) { js("onSpeechError('Je n\\'ai pas compris.')") }
                    override fun onReadyForSpeech(p: android.os.Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rms: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(p: android.os.Bundle?) {}
                    override fun onEvent(t: Int, p: android.os.Bundle?) {}
                })
                startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                })
            }
        }

        /** historyJson : [{"role":"user","content":"..."}, ...] */
        @JavascriptInterface fun ask(historyJson: String) {
            val key = prefs.getString("key", "") ?: ""
            if (key.isBlank()) {
                js("onAnswerError('Ajoute ta clé API dans les paramètres.')")
                return
            }
            Thread {
                var connection: HttpURLConnection? = null
                try {
                    val body = JSONObject()
                        .put("model", model)
                        .put("max_tokens", 400)
                        .put("system", system)
                        .put("messages", JSONArray(historyJson))
                    val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                    connection = c
                    c.requestMethod = "POST"
                    c.connectTimeout = 15000
                    c.readTimeout = 60000
                    c.doOutput = true
                    c.setRequestProperty("content-type", "application/json")
                    c.setRequestProperty("x-api-key", key)
                    c.setRequestProperty("anthropic-version", "2023-06-01")
                    c.outputStream.use { it.write(body.toString().toByteArray()) }
                    val code = c.responseCode
                    val text = (if (code in 200..299) c.inputStream else c.errorStream)
                        .bufferedReader().use { it.readText() }
                    if (code in 200..299) {
                        val out = JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text")
                        js("onAnswer(${JSONObject.quote(out)})")
                    } else {
                        val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { "Erreur $code" }
                        js("onAnswerError(${JSONObject.quote(msg)})")
                    }
                } catch (e: Exception) {
                    js("onAnswerError(${JSONObject.quote(e.message ?: "Erreur réseau")})")
                } finally {
                    connection?.disconnect()
                }
            }.start()
        }
    }
}
