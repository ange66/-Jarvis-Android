package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.Locale

/** Écoute au premier plan : démarrage explicite depuis l'application ouverte. */
class WakeWordService : Service(), TextToSpeech.OnInitListener {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var waitingForCommand = false
    private var speaking = false
    private var ttsReady = false

    override fun onCreate() {
        super.onCreate()
        getSharedPreferences("jarvis", MODE_PRIVATE).edit().putBoolean("wake_active", true).apply()
        createChannel()
        startForeground(NOTIFICATION_ID, notification("En attente de « Hey Jarvis »"))
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Jarvis:WakeWord")
        wakeLock?.acquire()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) startListening(700)
        else speak("La reconnaissance vocale n'est pas disponible sur ce téléphone.")
        return START_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val languageStatus = tts?.setLanguage(Locale.FRANCE)
            ttsReady = languageStatus != TextToSpeech.LANG_MISSING_DATA && languageStatus != TextToSpeech.LANG_NOT_SUPPORTED
            tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { speaking = true }
                override fun onDone(utteranceId: String?) {
                    speaking = false
                    handler.post { startListening(500) }
                }
                override fun onError(utteranceId: String?) {
                    speaking = false
                    handler.post { startListening(700) }
                }
            })
        }
    }

    private fun startListening(delay: Long) {
        handler.postDelayed({
            if (speaking || !SpeechRecognizer.isRecognitionAvailable(this)) return@postDelayed
            try {
                recognizer?.destroy()
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onResults(results: Bundle?) {
                            val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                            handlePhrase(phrase)
                        }
                        override fun onError(error: Int) { startListening(900) }
                        override fun onReadyForSpeech(params: Bundle?) {}
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {}
                        override fun onPartialResults(partialResults: Bundle?) {}
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                    startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
                        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    })
                }
                updateNotification(if (waitingForCommand) "Je vous écoute…" else "En attente de « Hey Jarvis »")
            } catch (_: Exception) { startListening(1500) }
        }, delay)
    }

    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(Locale.FRENCH), Normalizer.Form.NFD)
        .replace("\\p{Mn}+".toRegex(), "").replace("[^a-z0-9 ]".toRegex(), " ").replace("\\s+".toRegex(), " ").trim()

    private fun handlePhrase(phrase: String) {
        if (phrase.isBlank()) { startListening(500); return }
        val clean = normalize(phrase)
        if (!waitingForCommand) {
            val wakePhrases = listOf("hey jarvis", "ok jarvis", "jarvis")
            val wake = wakePhrases.firstOrNull { clean.startsWith(it) }
            if (wake != null) {
                val command = clean.removePrefix(wake).trim()
                if (command.isNotBlank()) {
                    waitingForCommand = false
                    answerCommand(command)
                } else {
                    waitingForCommand = true
                    speak("Oui chef, je vous écoute.")
                }
            } else startListening(350)
            return
        }
        waitingForCommand = false
        updateNotification("Commande reçue")
        answerCommand(phrase)
    }

    private fun answerCommand(command: String) {
        val q = normalize(command)
        when {
            q.contains("quelle heure") || q == "heure" -> speak("Il est " + java.text.SimpleDateFormat("HH:mm", Locale.FRANCE).format(java.util.Date()))
            q.contains("quelle date") || q.contains("quel jour") -> speak("Nous sommes le " + java.text.SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(java.util.Date()))
            q.contains("arrete") || q.contains("stop jarvis") -> speak("D'accord chef. Je reste en veille.")
            else -> askAi(command)
        }
    }

    private fun askAi(command: String) {
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("key", "").orEmpty()
        if (key.isBlank()) {
            speak("Chef, ajoutez votre clé API dans les paramètres de Jarvis pour que je puisse répondre à cette question.")
            return
        }
        Thread {
            var connection: HttpURLConnection? = null
            try {
                val system = "Tu es Jarvis, un assistant personnel vocal. Réponds toujours en français, naturellement, en une à trois phrases courtes, adaptées à une lecture à voix haute."
                val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 350).put("system", system)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", command)))
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                connection = c
                c.requestMethod = "POST"
                c.connectTimeout = 15000
                c.readTimeout = 45000
                c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val response = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
                val answer = if (code in 200..299) JSONObject(response).getJSONArray("content").getJSONObject(0).getString("text")
                    else "Je rencontre un problème avec le service d'intelligence artificielle. Vérifiez votre clé API et votre connexion."
                handler.post { speak(answer) }
            } catch (_: Exception) {
                handler.post { speak("Je n'arrive pas à me connecter à Internet, chef.") }
            } finally { connection?.disconnect() }
        }.start()
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_voice")
        else startListening(1500)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Écoute vocale JARVIS", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Indique lorsque JARVIS attend le mot de réveil"
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder: Notification.Builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }
        builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS – mode mains libres").setContentText(message).setContentIntent(open)
            .setOngoing(true).addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Désactiver", stop).build())
        return builder.build()
    }

    private fun updateNotification(message: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification(message))
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel(); recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        if (wakeLock?.isHeld == true) wakeLock?.release()
        getSharedPreferences("jarvis", MODE_PRIVATE).edit().putBoolean("wake_active", false).apply()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.example.jarvis.STOP_WAKE_SERVICE"
        private const val CHANNEL_ID = "jarvis_voice_channel"
        private const val NOTIFICATION_ID = 4102
    }
}
