JARVIS V3 — ASSISTANT VOCAL FRANÇAIS
Projet Android pour Samsung Galaxy S20 FE / Android 8+

FONCTIONS
- Discussion écrite avec l'assistant IA en français.
- Reconnaissance vocale en français (fr-FR) et réponse vocale française.
- Mode mains libres « Hey Jarvis » avec service Android au premier plan.
- Le mode mains libres peut rester actif lorsque l'écran est verrouillé, tant qu'Android ne suspend pas le service et que le service de reconnaissance vocale reste disponible.
- Commandes locales : demander l'heure ou la date.
- Réponses IA vocales via l'API Anthropic, avec la clé configurée dans l'application.
- Notification persistante avec action pour désactiver le mode mains libres.

ACTIVER LE MODE « HEY JARVIS »
1. Installer et ouvrir JARVIS.
2. Autoriser le microphone et les notifications lorsque Android le demande.
3. Ouvrir ⚙ et enregistrer une clé API Anthropic valide.
4. Revenir à l'écran principal et toucher « Activer Hey Jarvis ».
5. Garder la notification « JARVIS – mode mains libres » active.
6. Verrouiller le téléphone et dire « Hey Jarvis ». Jarvis répond « Oui chef, je vous écoute ». Dire ensuite sa question.
7. Pour arrêter, toucher le bouton dans l'application ou « Désactiver » dans la notification.

COMPILATION SANS ORDINATEUR (GITHUB ACTIONS)
Le dossier contient .github/workflows/build-apk.yml.
1. Sur le téléphone, ouvrir github.com et se connecter.
2. Créer un dépôt public ou privé nommé Jarvis-Android.
3. Décompresser ce ZIP avec une application de fichiers, puis envoyer le CONTENU du dossier Jarvis dans le dépôt (pas le dossier ZIP lui-même).
4. Dans le dépôt GitHub, ouvrir l'onglet Actions.
5. Sélectionner « Construire JARVIS APK », puis « Run workflow » si le lancement ne se fait pas automatiquement après l'envoi.
6. Quand l'exécution est terminée avec succès, ouvrir l'exécution, descendre à Artifacts et télécharger « JARVIS-V3-APK ».
7. Décompresser l'archive téléchargée et installer app-debug.apk. Autoriser l'installation depuis le navigateur ou l'application Fichiers si Android le demande.

CLÉ API ET COÛTS
- Une clé API Anthropic est nécessaire pour les réponses IA. Un abonnement ChatGPT ne remplace pas cette clé.
- Les appels API peuvent être payants. Vérifier les tarifs et la consommation dans le compte Anthropic.
- La clé est conservée localement dans les préférences de l'application, sans chiffrement dédié. Ne partagez pas l'APK avec votre clé.
- Pour une distribution publique, déplacer les appels API vers un serveur sécurisé.

LIMITES IMPORTANTES DU MODE MAINS LIBRES
- Android exige que l'utilisateur démarre l'écoute depuis l'application visible. Le mode ne peut pas s'activer tout seul au démarrage du téléphone.
- L'écoute repose sur le service de reconnaissance vocale installé sur le téléphone. Elle peut nécessiter Internet, utiliser des données mobiles et consommer davantage de batterie.
- La détection « Hey Jarvis » n'est pas une puce matérielle dédiée ni une garantie d'écoute permanente. Samsung/Android peut arrêter le service selon les réglages d'économie d'énergie, un manque de mémoire ou une restriction du fournisseur de reconnaissance vocale.
- Pour améliorer la continuité : Paramètres > Applications > JARVIS > Batterie > choisir « Sans restriction » si cette option est disponible. Vérifier aussi que le microphone est autorisé.
- Jarvis ne déverrouille pas le téléphone et ne contourne pas le code PIN, le mot de passe ou l'empreinte digitale.
- Le téléphone affiche une notification persistante pendant l'écoute. Arrêter le mode si vous ne souhaitez pas que le microphone soit utilisé.

TECHNIQUE
- Namespace/applicationId : com.example.jarvis
- minSdk 26, targetSdk 34
- Java 17, Kotlin 1.9.24, Android Gradle Plugin 8.5.2, Gradle 8.7
- Version : 3.0 (versionCode 3)
- Le workflow GitHub compile avec Gradle 8.7 et Java 17.
